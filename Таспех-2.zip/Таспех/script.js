document.addEventListener('DOMContentLoaded', () => {
    const counterElement = document.getElementById('counter');
    const tapButton = document.getElementById('tapButton');
    const historyList = document.getElementById('historyList');

    // Загрузка данных из LocalStorage
    let tapData = JSON.parse(localStorage.getItem('tapData')) || {
        currentCount: 0,
        history: {}
    };

    // Отображение текущего счетчика
    counterElement.textContent = tapData.currentCount;

    // Обновление истории
    updateHistory();

    // Обработка нажатия на кнопку
    tapButton.addEventListener('click', () => {
        tapData.currentCount++;
        counterElement.textContent = tapData.currentCount;

        // Получение текущей даты в формате YYYY-MM-DD
        const today = new Date().toISOString().split('T')[0];

        // Обновление истории за сегодня
        tapData.history[today] = (tapData.history[today] || 0) + 1;

        // Сохранение данных
        localStorage.setItem('tapData', JSON.stringify(tapData));

        // Обновление отображения истории
        updateHistory();
    });

    // Функция для отображения истории
    function updateHistory() {
        historyList.innerHTML = '';
        const today = new Date();
        
        // Показываем историю за последние 7 дней
        for (let i = 0; i < 7; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            const count = tapData.history[dateStr] || 0;

            const li = document.createElement('li');
            const formattedDate = i === 0 ? 'Сегодня' : 
                                 i === 1 ? 'Вчера' : 
                                 i === 2 ? 'Позавчера' : 
                                 date.toLocaleDateString('ru-RU');
            li.textContent = `${formattedDate}: ${count} тапов`;
            historyList.appendChild(li);
        }
    }

    // Регистрация Service Worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js')
            .then(reg => console.log('Service Worker зарегистрирован', reg))
            .catch(err => console.error('Ошибка регистрации Service Worker:', err));
    }
});